import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.util.TokenFilterFactory;
import org.apache.lucene.util.AttributeFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Map;

public class progTask3 {
    private static class BiTokenizer extends TokenFilter {

        private final CharTermAttribute termAttr = input.getAttribute(CharTermAttribute.class);
        String tmp1;
        int count =0;

        protected BiTokenizer(TokenStream input) {
            super(input);
        }

        @Override
        public boolean incrementToken() throws IOException {
            if(input.incrementToken()){
                if(count == 0){
                    tmp1 = termAttr.toString();
                    input.incrementToken();
                    count++;
                }
                String tmp2 = termAttr.toString();
                String arr = tmp1.concat(" ".concat(tmp2));
                tmp1 = tmp2;
                termAttr.copyBuffer(arr.toCharArray(), 0, arr.toCharArray().length);
                return true;
            }else return false;
        }

        @Override
        public void reset() throws IOException {
            super.reset();
        }
    }
    private static class BiTokenizerFactory extends TokenFilterFactory {

        public BiTokenizerFactory(Map<String, String> args) {
            super(args);
            if (!args.isEmpty()) {
                throw new IllegalArgumentException("Unknown parameters: " + args);
            }
        }

        @Override
        public TokenStream create(TokenStream tokenStream) {
            return new BiTokenizer(tokenStream);
        }
    }

    public static void main(String[] args) {

        String text = """
                Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today.
                Sunny Berlin! Berlin is always exciting!
                """;
        String query = "New York University";
        String doc = "The New York medical institute outsourced a lot of its Covid-19 research\n" +
                "to the renowned York University in Ontario, Canada.";
        ArrayList<String> queryTokens = new ArrayList<>();
        ArrayList<String> textTokens = new ArrayList<>();
        ArrayList<String> docTokens = new ArrayList<>();

        try(StandardTokenizer tmpTokenizer = new StandardTokenizer(AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY)){
//------------------- Sub-question a) -------------------

            tmpTokenizer.setReader(new StringReader(text.toLowerCase()));
            BiTokenizer textTokenizer = new BiTokenizer(tmpTokenizer);
            textTokenizer.reset();

            while(textTokenizer.incrementToken()){
                CharTermAttribute attribute = textTokenizer.getAttribute(CharTermAttribute.class); // to get each token
                textTokens.add(attribute.toString());
            }
            textTokenizer.close();
            System.out.println(textTokens);

//------------------- Sub-question b) -------------------

            tmpTokenizer.setReader(new StringReader(query.toLowerCase()));
            BiTokenizer queryTokenizer = new BiTokenizer(tmpTokenizer);
            queryTokenizer.reset();
            while(queryTokenizer.incrementToken()){
                CharTermAttribute attribute = queryTokenizer.getAttribute(CharTermAttribute.class); // to get each token
                queryTokens.add(attribute.toString());
            }
            queryTokenizer.close();
            tmpTokenizer.setReader(new StringReader(doc.toLowerCase()));
            BiTokenizer docTokenizer = new BiTokenizer(tmpTokenizer);
            docTokenizer.reset();
            while(docTokenizer.incrementToken()){
                CharTermAttribute attribute = docTokenizer.getAttribute(CharTermAttribute.class); // to get each token
                docTokens.add(attribute.toString());
            }
            docTokenizer.close();
            System.out.println("\n\n False positive example -");
            System.out.println("\nDoes the following text : '" + doc + "'\n contain the following query : '" + query + "' ? \n");
            int flag =1;
            for(String biWord : queryTokens){
                if (!docTokens.contains(biWord)) {
                    flag = 0;
                    break;
                }
            }
            System.out.println(flag==1);


        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
