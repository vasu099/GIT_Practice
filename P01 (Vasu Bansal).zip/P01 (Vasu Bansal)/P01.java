import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.core.WhitespaceTokenizer;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.util.AttributeFactory;

public class P01 {

    public static void standardtoken() throws IOException{

        AttributeFactory fac = AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY;
        String text = "Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today. Sunny Berlin! Berlin is always exciting!";


        try (StandardTokenizer tokenizer1 = new StandardTokenizer(fac)) {
            tokenizer1.setReader(new StringReader(text));
            tokenizer1.reset();

            CharTermAttribute token = tokenizer1.addAttribute(CharTermAttribute.class);

            System.out.println("Tokens from Standard Tokeniser:");

            while(tokenizer1.incrementToken()) {
                System.out.println(token);
            }

            }


    }

    public static void whitespacetoken() throws IOException{

        AttributeFactory fac = AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY;
        String text = "Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today. Sunny Berlin! Berlin is always exciting!";


        try (WhitespaceTokenizer tokenizer2 = new WhitespaceTokenizer(fac)) {
            tokenizer2.setReader(new StringReader(text));
            tokenizer2.reset();

            CharTermAttribute token = tokenizer2.addAttribute(CharTermAttribute.class);

            System.out.println("Tokens from White Space Tokeniser:");

            while(tokenizer2.incrementToken()) {
            
                System.out.println(token);
            }
        }


    }

    public static void stopword() throws IOException{

        AttributeFactory fac = AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY;
        String text = "Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today. Sunny Berlin! Berlin is always exciting!";


            TokenStream tokenizer3 = new StandardTokenizer(fac); 
            ((Tokenizer) tokenizer3).setReader(new StringReader(text));
            

            List<String> stopwordlist = Arrays.asList("was", "is", "in", "to", "be");

            CharTermAttribute token = tokenizer3.addAttribute(CharTermAttribute.class);

            CharArraySet stopwords = new CharArraySet(stopwordlist,true);

            tokenizer3 = new StopFilter(tokenizer3, stopwords);

            tokenizer3.reset();

            System.out.println("Tokens after Stop Word Filtering:");

            while(tokenizer3.incrementToken()) {
                System.out.println(token);
            }     


    }

    public static void customAnalyser() throws IOException{

        String text = "Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today. Sunny Berlin! Berlin is always exciting!";

        CustomAnalyzer customs  = CustomAnalyzer.builder(Paths.get("resources"))
                        .withTokenizer("standard")
                        .addTokenFilter("lowercase")
                        .addTokenFilter("porterstem")
                        .addTokenFilter("stop", "ignoreCase", "false", "words", "stopwordlist.txt", "format", "wordset")
                        .build();

        

        TokenStream tokenizer4 = customs.tokenStream("", new StringReader(text)); 
            

        CharTermAttribute token = tokenizer4.addAttribute(CharTermAttribute.class);

        tokenizer4.reset();

        System.out.println("Tokens from custom analyser");

        while(tokenizer4.incrementToken()) {
            System.out.println(token);
        }


    }


    public static void main(String args[]) throws IOException{

        standardtoken();
        whitespacetoken();
        stopword();
        customAnalyser();
    }
    
}
