import sys
import getopt
import csv
import pandas as pd
import numpy as np

argv = sys.argv[1:]
try:
    opts, argv = getopt.getopt(argv, '', ["data=", "k="])
    for opt,val in opts:
        if opt in ("--data"):
            file_path = val
            
except getopt.error as err:
	print (str(err))


data = pd.read_csv(file_path, header = None)

#CALCULATING MEAN: CLASS A
df = pd.DataFrame(data)

df1 = df[0] == 'A'
df2 = df[0] == 'B'
x = df[df1]
y = df[df2]

x1_mean = x[1].mean()
x1_var = x[1].var()
x2_mean = x[2].mean()
x2_var = x[2].var()

y1_mean = y[1].mean()
y1_var = y[1].var()
y2_mean = y[2].mean()
y2_var = y[2].var()

p_x = x.size/df.size
p_y = y.size/df.size

print(x1_mean , x1_var, x2_mean, x2_var, p_x)
print(y1_mean , y1_var, y2_mean, y2_var, p_y)

#CALCULATION: MIS - CLASSIFICATION

#CALCULATING P
def GaussProb(val,  mean, var):
    eq1 = np.exp(-((val - mean) ** 2 / (2 * var)))
    return (1 / ((2 * np.pi * var)** .5 )) * eq1

list_x = df[df1].values.tolist()
list_y = df[df2].values.tolist()

count =0;

df_list = df.values.tolist();

for ind, i in enumerate(df_list):
    p_x1 = GaussProb(i[1], x1_mean, x1_var )
    p_y1 = GaussProb(i[2], x2_mean, x2_var )
    p_x2 = GaussProb(i[1], y1_mean, y1_var )
    p_y2 = GaussProb(i[2], y2_mean, y2_var )
    prob_pX = p_x1 * p_y1 * p_x
    prob_pY = p_x2 * p_y2 * p_y
    if((i[0] == 'A' and prob_pX < prob_pY) or (i[0]=='B' and prob_pX > prob_pY)):
        count+=1

print(count)
