import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.document.StringField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.MultiFields;
import org.apache.lucene.index.PostingsEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.search.similarities.ClassicSimilarity;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;

public class progTask4 {

    static Directory index = new RAMDirectory();

    private static void addDoc(IndexWriter writer, String content, String docID) throws
        IOException { // function to add a document to IndexWriter
        Document doc = new Document();

        FieldType fType =
            new FieldType(); // custom fieldType to make tracking term positions possible
        fType.setStored(true);
        fType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS);
        fType.setTokenized(true);
        fType.setStoreTermVectors(true);
        fType.setStoreTermVectorPositions(true);

        doc.add(new StringField("docID", docID, Field.Store.YES));
        doc.add(new Field("content", content, fType));
        writer.addDocument(doc);
    }

    public static TreeMap<String, ArrayList<Double>> getTF_IDFmatrix(String text, Analyzer analyzer)
        throws IOException, ParseException {
        //function to generate TF_IDF matrix of the given documents using a custom Analyzer
        //log base 10 used to calculate idf
        TreeMap<String, ArrayList<Double>> tfIdFmatrix = new TreeMap<>();
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter writer = new IndexWriter(index, config);

        String[] textSplit = text.split("[.!?]");
        int i = 1;
        for (String tmp : textSplit) {
            addDoc(writer, tmp, "d" + i);
            i++;
        }
        writer.close();

        ArrayList<String> tokens = new ArrayList<>();
        TokenStream stream = analyzer.tokenStream(text, text);
        stream.reset();

        while (stream.incrementToken()) {
            CharTermAttribute attribute = stream.getAttribute(CharTermAttribute.class);
            tokens.add(attribute.toString());
        }
        stream.close();

        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        int totalDocs = reader.numDocs();

        Term term;
        PostingsEnum docEnum;
        for (String token : tokens) {
            Query tmpQuery = new QueryParser("content", analyzer).parse(token);
            term = new Term("content", token.toLowerCase());
            docEnum = MultiFields.getTermDocsEnum(reader, "content", term.bytes());
            ArrayList<Double> tfIdfweights = new ArrayList<>(Collections.nCopies(totalDocs, 0.0));
            double termIdf = Math.log10((double) totalDocs / (double) searcher.count(tmpQuery));
            for (int k = 0; k < searcher.count(tmpQuery); k++) {
                docEnum.nextDoc();
                tfIdfweights.add(docEnum.docID(), (double) docEnum.freq() * termIdf);
            }
            tfIdFmatrix.put(token, tfIdfweights);

        }

        return tfIdFmatrix;
    }

    public static TreeMap<Float, String> tfIdfScoring(Query query) throws IOException {
        //function to score the documents on the query using TF_IDF similarity
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        searcher.setSimilarity(new ClassicSimilarity());
        TreeMap<Float, String> tfIdfScores = new TreeMap<>(Collections.reverseOrder());
        Scorer scorer = query.createWeight(searcher, true, 1).scorer(reader.leaves().get(0));
        DocIdSetIterator docIdSetIterator = scorer.iterator();

        while (docIdSetIterator.nextDoc() != DocIdSetIterator.NO_MORE_DOCS) {
            tfIdfScores.put(scorer.score(), reader.document(scorer.docID()).get("content"));
        }
        return tfIdfScores;
    }

    public static TreeMap<Float, String> bm25Scoring(Query query) throws IOException {
        //function to score the documents on the query using the recommended BM25 similarity
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        searcher.setSimilarity(new BM25Similarity());
        TreeMap<Float, String> bm25Scores = new TreeMap<>(Collections.reverseOrder());
        Scorer scorer = query.createWeight(searcher, true, 1).scorer(reader.leaves().get(0));
        DocIdSetIterator docIdSetIterator = scorer.iterator();

        while (docIdSetIterator.nextDoc() != DocIdSetIterator.NO_MORE_DOCS) {
            bm25Scores.put(scorer.score(), reader.document(scorer.docID()).get("content"));
        }
        return bm25Scores;
    }

    public static double euclideanDistance(ArrayList<Double> v1, ArrayList<Double> v2) {
        //function to calculate euclidean distance b/w 2 vectors
        double result = 0;
        assert (v1.size() == v2.size());
        for (int i = 0; i < v1.size(); i++) {
            result += Math.pow(v1.get(i) - v2.get(i), 2);
        }
        return Math.sqrt(result);
    }

    public static double dotProduct(ArrayList<Double> v1, ArrayList<Double> v2) {
        //function to calculate dot product b/w 2 vectors
        double result = 0;
        assert (v1.size() == v2.size());
        for (int i = 0; i < v1.size(); i++) {
            result += v1.get(i) * v2.get(i);
        }
        return result;
    }

    public static double cosineSim(ArrayList<Double> v1, ArrayList<Double> v2) {
        //function to calculate the cosine similarity b/w 2 vectors
        double result = 0;
        double v1Mag = 0;
        double v2Mag = 0;
        assert (v1.size() == v2.size());
        for (int i = 0; i < v1.size(); i++) {
            v1Mag += Math.pow(v1.get(i), 2);
            v2Mag += Math.pow(v2.get(i), 2);
            result += v1.get(i) * v2.get(i);
        }
        v1Mag = Math.sqrt(v1Mag);
        v2Mag = Math.sqrt(v2Mag);

        return result / (v1Mag * v2Mag);
    }

    public static void main(String[] args) {
        try (Analyzer customAna = CustomAnalyzer.builder()
            .withTokenizer("standard")
            .addTokenFilter("lowercase")
            .build()) {
            //----------------------- Sub-question a) -----------------------
            String text =
                "Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today. " +
                    "Sunny Berlin! Berlin is always exciting!";
            System.out.println("TF-IDF matrix: \n");
            System.out.println("    [D1,      D2,       D3,       D4,       D5,       D6]\n");
            TreeMap<String, ArrayList<Double>> tdIdfMatrix = getTF_IDFmatrix(text, customAna);
            tdIdfMatrix.forEach((k, v) -> System.out.println(k + " = " + v));

            ArrayList<Double> d1V = new ArrayList<>();
            ArrayList<Double> d2V = new ArrayList<>();

            tdIdfMatrix.forEach((k, v) -> d1V.add(v.get(0)));
            tdIdfMatrix.forEach((k, v) -> d2V.add(v.get(1)));

            System.out.println("\nDocument 1 vector: " + d1V);
            System.out.println("Document 2 vector: " + d2V);

            System.out.println("\nSimilarity b/w D1 and D2 using Euclidean distance = " +
                1 / (1 + euclideanDistance(d1V, d2V)));
            System.out.println(
                "Similarity b/w D1 and D2 using Dot product = " + dotProduct(d1V, d2V));
            System.out.println(
                "Similarity b/w D1 and D2 using cosine = " + cosineSim(d1V, d2V) + "\n");

            //----------------------- Sub-question b) -----------------------
            Query query = new QueryParser("content", customAna).parse("She is a sunny girl.");
            System.out.println("QUERY: 'She is a sunny girl.'");
            System.out.println("Scoring using VSM -> ");
            tfIdfScoring(query).forEach((k, v) -> System.out.println(k + " : " + v));
            System.out.println("\nScoring using BM25 model -> ");
            bm25Scoring(query).forEach((k, v) -> System.out.println(k + " : " + v));

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
