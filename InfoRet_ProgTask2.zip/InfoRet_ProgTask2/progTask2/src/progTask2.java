import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;


public class progTask2 {

    static Directory index = new RAMDirectory(); // universal index to hold tokens

    private static void addDoc(IndexWriter writer, String content, String docID) throws IOException { // function to add a document to IndexWriter
        Document doc = new Document();

        FieldType fType = new FieldType(); // custom fieldType to make tracking term positions possible
        fType.setStored(true);
        fType.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS);
        fType.setTokenized(true);
        fType.setStoreTermVectors(true);
        fType.setStoreTermVectorPositions(true);

        doc.add(new StringField("docID", docID, Field.Store.YES));
        doc.add(new Field("content", content, fType));
        writer.addDocument(doc);
    }

    public static TreeMap<String, ArrayList<ArrayList<Integer>>> createInvertedIndex (String text, Analyzer analyzer) throws IOException, ParseException {
        //functions creates and returns an inverted index for a text (splits text into documents using {. ? !} as delimiters)
        //inverted index returned as a TreeMap with token names as keys
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter writer = new IndexWriter(index, config);

        TreeMap<String, ArrayList<ArrayList<Integer>>> invertedIndex = new TreeMap<>();

        String[] textSplit = text.split("[.!?]");
        int i =1;
        for (String tmp : textSplit) {
            addDoc(writer, tmp, "d" + i);
            i++;
        }

        writer.close();

        ArrayList<String> analyzerTokensList = new ArrayList<>();
        TokenStream stream = analyzer.tokenStream(text, text);
        stream.reset();

        while(stream.incrementToken()){
            CharTermAttribute attribute = stream.getAttribute(CharTermAttribute.class);
            analyzerTokensList.add(attribute.toString());
        }

        stream.close();
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);

        ScoreDoc[] hits;
        Term term;
        PostingsEnum docEnum;// to track documents containing a particular token

        for (String token : analyzerTokensList){

            hits = searcher.search(new QueryParser("content", analyzer).parse(token), 10, Sort.INDEXORDER).scoreDocs;
            term = new Term("content", token.toLowerCase());
            docEnum = MultiFields.getTermDocsEnum(reader, "content", term.bytes());
            ArrayList<ArrayList<Integer> > postingsWithDocFreq = new ArrayList<>();
            ArrayList<Integer> postings = new ArrayList<>();
            ArrayList<Integer> docFreq = new ArrayList<>();
            docFreq.add(hits.length);
            for (int k =0; k < hits.length; k++){
                docEnum.nextDoc();
                postings.add(docEnum.docID()+1);
            }
            postingsWithDocFreq.add(docFreq);
            postingsWithDocFreq.add(postings);
            invertedIndex.put(token, postingsWithDocFreq);

        }

        return invertedIndex;

    }

    public static void printTokenInfo(String token, TreeMap<String, ArrayList<ArrayList<Integer>>> invertedIndex) throws IOException {
        //prints the token info in the required format:
        //[tokenname:total frequency:doc frequency]->[docid:frequency:[positions]]->[docid:frequency:[positions]]

        IndexReader reader = DirectoryReader.open(index);
        int totalFreq =0;
        String tokenTmp = token.toLowerCase();
        Term term = new Term("content", tokenTmp);
        PostingsEnum docPosEnum = MultiFields.getTermPositionsEnum(reader, "content", term.bytes());
        ArrayList<Integer> wordPosts = invertedIndex.get(tokenTmp).get(1);
        System.out.println();
        while (docPosEnum.nextDoc() != DocIdSetIterator.NO_MORE_DOCS){
            totalFreq += docPosEnum.freq();
        }
        docPosEnum = MultiFields.getTermPositionsEnum(reader, "content", term.bytes());
        System.out.println("tokenName:"+tokenTmp + " |total_word_freq:"+totalFreq+" |doc_freq:"+wordPosts.size());
        for (int id : wordPosts){
            docPosEnum.nextDoc();
            ArrayList<Integer> positions = new ArrayList<>();
            for (int j = 0; j < docPosEnum.freq(); ++j) {
                positions.add(docPosEnum.nextPosition()+1);
            }
            System.out.println(" -> docID:"+id+" freq:"+docPosEnum.freq()+" positions:"+positions);
        }

    }

    public static ArrayList<Integer> intersectPostings (String str1, String str2, TreeMap<String, ArrayList<ArrayList<Integer>>> invertedIndex){
        //used to find the Intersect of 2 posting lists
        ArrayList<Integer> intersect = new ArrayList<>();
        ArrayList<Integer> post1 = invertedIndex.get(str1.toLowerCase()).get(1);
        ArrayList<Integer> post2 = invertedIndex.get(str2.toLowerCase()).get(1);

        int i =0, j=0;

        while(i < post1.size() && j < post2.size()){
            if (post1.get(i) < post2.get(j)){
                i++;
            }
            else if (post2.get(j) <post1.get(i)){
                j++;
            }
            else{
                intersect.add(post1.get(i++));
                j++;
            }
        }
        return intersect;
    }

    public static void main(String[] args) {

        try(Analyzer customAna = CustomAnalyzer.builder()
                .withTokenizer("standard")
                .addTokenFilter("lowercase")
                .build()){
            //----------------------- Sub-question a) -----------------------
            String text= "Today is sunny. She is a sunny girl. To be or not to be. She is in Berlin today. "+
                    "Sunny Berlin! Berlin is always exciting!";

            TreeMap<String, ArrayList<ArrayList<Integer>>> invertedIndex = createInvertedIndex(text, customAna);

            System.out.println("Inverted index for the following text : " + text + "\n");

            invertedIndex.forEach((k, v) -> System.out.println(k + " -> docFreq:" + v.get(0) + " -> postings" + v.get(1)));

            System.out.println("\nDocuments that contain 'sunny' and 'exciting' : " + intersectPostings("sunny", "exciting", invertedIndex));
            System.out.println("\nDocuments that contain 'is' and 'sunny' : " + intersectPostings("is", "sunny", invertedIndex));

            //----------------------- Sub-question b) -----------------------
            printTokenInfo("sunny", invertedIndex);
            printTokenInfo("to", invertedIndex);


        }catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}

