import getopt
import sys
import math
import numpy as np
import pandas as pd

    

def calWeights(Max, Min, class1):
    wt1 = 0
    wt2 = 0
    for i in class1:
        if i[0]=='A':
            wt1 += (Max-i[1])/(Max-Min)
        elif i[0]=='B':
            wt2 += (Max-i[1])/(Max-Min)
    return wt1, wt2


def CalDist(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)


def CalErr(data, cb, k):
    err = 0
    for i in range(data.shape[0]):
        obj = data.loc[i]

        if len(cb.loc[(cb[0]==obj[0]) & (cb[1]==obj[1]) & (cb[2]==obj[2])])!=0:
            continue
        
        class1 = []
        for j in range(cb.shape[0]):
            cbObj = cb.loc[j]
            Dist = CalDist([obj[1], obj[2]], [cbObj[1], cbObj[2]])
            class1.append((cbObj[0], Dist))

        class1 = sorted(class1, key=lambda x: x[1])[0:k]
        Max = max(class1, key=lambda x: x[1])
        Min = min(class1, key=lambda x: x[1])

        wt1, wt2 = calWeights(Max[1], Min[1],class1)
        if wt2>wt1 and obj[0]!='B':
            err+=1
        elif wt2<wt1 and obj[0]!='A':
            err+=1
    return err
        

if __name__=="__main__":

    info, v = getopt.getopt(sys.argv[1:], "", ["data=", "k="])
    for key, val in info:
        if key == "--data":
            data = val        
        elif key == "--k":
            k = val

    data = pd.read_csv(data, header=None)

    cb = pd.DataFrame(data.loc[0]).T
    for i in range(1,data.shape[0]):
        obj = data.loc[i]
        n1 = ""
        minDist = 999
        
        for j in range(cb.shape[0]):
            cbObj = cb.loc[j]
            Obj_cbObjDist = CalDist([obj[1], obj[2]], [cbObj[1], cbObj[2]])
            if minDist>Obj_cbObjDist:
                minDist = Obj_cbObjDist
                n1 = cbObj[0]
        
        if n1!=obj[0]:
            cb = cb.append(obj, ignore_index=True)
    

    err = CalErr(data, cb, int(k))
    print(err)

    for i in range(len(cb)):
            cbObj = cb.loc[i]
            print(cbObj[0],cbObj[1],cbObj[2],sep=",")
    
