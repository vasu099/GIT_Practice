
import sys
import numpy as np
import pandas as pd

input = ["--data"]
input_len = len(sys.argv)


if input_len-1 != 2*len(input):
	print(f"INPUT ERROR")
	sys.exit(1)

info = []

for i in range(len(input)):
	for j in range(1, len(sys.argv)):
		if input[i] == sys.argv[j] and sys.argv[j+1]:
			info.append(sys.argv[j+1])

if len(info) != len(input):
	print(f"INPUT ERROR")
	sys.exit(1)

data = pd.read_csv(info[0], header=None)

col_header = np.array([])
for i in range(len(data.columns)):
  col_header = np.append(col_header, f"att{i}")
data.columns = col_header

def log(base, vals):
  num = vals
  den = base
  return np.log(num) / np.log(den)

def entropy(exp_data, exp_key, exp_att):  
  result = 0
  prop = 1
  for i in range(len(exp_key)):
      den = len(exp_data.iloc[:, 0])
      if den != 0:
        prop = len(exp_data[exp_data[exp_att] == exp_key[i]].iloc[:, 0]) / den
      else:
        prop = 0
      if prop != 0:
        log_res = log(len(exp_key), prop)
        result = result + -1*prop*log_res
  return result

def info_gain(data, prev_entropy, exp_key, exp_att, new_branch):
  result = prev_entropy
  key_att = data[new_branch].unique()
  for i in range(len(key_att)):
    temporary = data[data[new_branch] == key_att[i]]
    prop = len(temporary.iloc[:, 0]) / len(data.iloc[:, 0])
    temp_entropy = entropy(temporary, exp_key, exp_att)
    result = result - prop*temp_entropy
  return result

def DT_ID3(data, depth, exp_key, exp_att, prev_entropy, prev_att, majority):
    
  info_gain_att = np.array([])
  info_gain1 = np.array([])
  columns = np.array([])
  if prev_att:
    for i in range(len(data.columns) - 1):
      if data.columns[i] != prev_att:
        columns = np.append(columns, data.columns[i])
  else:
    for i in range(len(data.columns) - 1):
        columns = np.append(columns, data.columns[i])
  for i in range(len(columns)):
    info_gain_att = np.append(info_gain_att, columns[i])
    info_gain1 = np.append(info_gain1, info_gain(data, prev_entropy, exp_key, exp_att, columns[i]))
    
  current_idx = 0
  for i in range(len(info_gain1)):
    if info_gain1[i] > info_gain1[current_idx]:
      current_idx = i
  if (info_gain1[current_idx]) == 0.0:
    return

  att_str = info_gain_att[current_idx]
  att_branches = data[att_str].unique()
  for i in range(len(att_branches)):
    branch = att_branches[len(att_branches) - (i+1)]
    filtered_data = data[data[att_str] == branch]
    new_entropy = entropy(filtered_data, exp_key=exp_key, exp_att=exp_att)
    if new_entropy == 0.0:
      leaf_node = filtered_data[exp_att].unique()[0]
      print(f"{depth},{att_str}={branch},{new_entropy},{leaf_node}")
    else:
      leaf_node = "no_leaf"
      print(f"{depth},{att_str}={branch},{new_entropy},{leaf_node}")
      DT_ID3(filtered_data, depth+1, exp_key, exp_att, new_entropy, att_str, majority=majority)
  
exp_att = data.columns[-1]
exp_key = data[exp_att].unique()
AllEntropy = entropy(exp_data=data, exp_key=exp_key, exp_att=exp_att)
print(f"{0},root,{AllEntropy},no_leaf")
depth = 1

key_val = data[exp_att].unique()
MaxValue = key_val[1]
for i in range(len(key_val)):
  if len(data[data[exp_att] == key_val[i]].iloc[:, 0]) > len(data[data[exp_att] == MaxValue].iloc[:, 0]):
    MaxValue = key_val[i]

DT_ID3(data,1,exp_key, data.columns[-1], AllEntropy, prev_att=None, majority=MaxValue)