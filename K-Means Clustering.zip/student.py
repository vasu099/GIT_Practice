
import math
import getopt
import sys
import numpy as np
import pandas as pd


def assignCents(obj, pt1, pt2, pt3):

    d1 = (obj[1]-pt1[0])**2 + (obj[2]-pt1[1])**2

    d2 = (obj[1]-pt2[0])**2 + (obj[2]-pt2[1])**2

    d3 = (obj[1]-pt3[0])**2 + (obj[2]-pt3[1])**2

    if d1<d2 and d1<d3:
        return "pt1", d1
    
    elif d2<d3:
        return "pt2", d2
    
    else:
        return "pt3", d3

 
def NewCents(args):
    size = len(args)
    x1=0
    y1=0
    
    for x in args:
        x1 += x[0]
        y1 += x[1] 
        

    return (x1/size, y1/size)


if __name__=="__main__":

    arguments, v = getopt.getopt(sys.argv[1:], "", ["data="])
    
    
    for hash, vals in arguments:
        if hash == "--data":
            info = vals

    data1 = pd.read_csv(info, header=None)[[1,2]]

    c1List = []
    c2List = []
    c3List = []

    maxIter=20
    crit1 = -math.inf
    crit = 0
        
    pt1 = (0,5)
    pt2 = (0,4)
    pt3 = (0,3)


    while(crit!=crit1 or maxIter>0):

        maxIter -= 1

        list1 = []
        list2 = []
        list3 = []

        crit1 = crit
        crit = 0

        for i in range(data1.shape[0]):
            
            obj = data1.loc[i]
            
            
            calCents, Dist = assignCents(obj, pt1, pt2, pt3)
            crit += Dist

            if(calCents=="pt1"):
                list1.append((obj[1], obj[2]))

            elif(calCents=="pt2"):
                list2.append((obj[1], obj[2]))

            elif(calCents=="pt3"):
                list3.append((obj[1], obj[2]))

        if(crit==crit1):
            continue


        print(crit)


        c1List.append(pt1)

        pt1 = NewCents(list1)

        c2List.append(pt2)

        pt2 = NewCents(list2)

        c3List.append(pt3)
        
        pt3 = NewCents(list3)


    size = len(c1List)
    
    for i in range(size):
        
        print(c1List[i][0], c1List[i][1], sep=",", end="\t")
        print(c2List[i][0], c2List[i][1], sep=",", end="\t")
        print(c3List[i][0], c3List[i][1], sep=",", end="\t")
        
        
        print()
    