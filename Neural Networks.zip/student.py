
import sys
import numpy as np
import csv
import pandas as pd


def NN(x_train,y_train,iters,learningRate):
  
    # GIVEN INITIALIZED WEIGHTS
    w_bias_h1 = 0.2
    w_bias_h2 = -0.5
    w_bias_h3 = 0.3
    w_bias_o = -0.1
    w_a_h1 = -0.3
    w_b_h1 = 0.4
    w_a_h2 = -0.1
    w_b_h2 = -0.4
    w_a_h3 = 0.2
    w_b_h3 = 0.1
    w_h1_o = 0.1
    w_h2_o = 0.3
    w_h3_o = -0.4
    
    

    weights=[w_bias_h1,w_a_h1,w_b_h1,w_bias_h2,w_a_h2,w_b_h2,w_bias_h3,w_a_h3,w_b_h3,w_bias_o,w_h1_o,w_h2_o,w_h3_o]

    for i in range(0,11):
        print('-', end=" ")
    for i in range(0,len(weights)):
        if(i==len(weights)-1):
            print(round(weights[i], 5))
        else:
            print(round(weights[i],5),end=" ")


    i=0
    while i< int(iters):
        for j in range(0,len(x_train)):
           
            bias=1
            a=x_train[j][0]
            b=x_train[j][1]

            h1Summation=bias*w_bias_h1 + a*w_a_h1 +b*w_b_h1
           
            h1Output=1 / (1 + np.exp(-h1Summation))
           

            h2Summation=bias*w_bias_h2 + a*w_a_h2 +b*w_b_h2
            h2Output=1 / (1 + np.exp(-h2Summation))

            h3Summation = bias * w_bias_h3 + a * w_a_h3 + b * w_b_h3
            h3Output = 1 / (1 + np.exp(-h3Summation))

            summation_o = h1Output*w_h1_o +h2Output*w_h2_o+h3Output*w_h3_o+ bias*w_bias_o
            finalOutput= 1 / (1 + np.exp(-summation_o))

            error=y_train[j]-finalOutput 

            #BACK_PROPAGATION
            delta_o=finalOutput*(1-finalOutput)*(y_train[j]-finalOutput)
            delta_h1=h1Output*(1-h1Output)*(w_h1_o*delta_o)
            delta_h2=h2Output*(1-h2Output)*(w_h2_o*delta_o)
            delta_h3=h3Output*(1-h3Output)*(w_h3_o*delta_o)

            delta_w_h1_o= learningRate*h1Output*delta_o
            delta_w_h2_o=learningRate*h2Output*delta_o
            delta_w_h3_o=learningRate*h3Output*delta_o
            delta_bias_o=learningRate*1*delta_o

            w_h1_o=w_h1_o+delta_w_h1_o
            w_h2_o=w_h2_o+delta_w_h2_o
            w_h3_o=w_h3_o+delta_w_h3_o
            w_bias_o=w_bias_o+delta_bias_o

            delta_w_a_h1=learningRate*a*delta_h1
            delta_w_b_h1=learningRate*b*delta_h1
            delta_w_bias_h1=learningRate*1*delta_h1

            w_a_h1=w_a_h1+delta_w_a_h1
            w_b_h1=w_b_h1+delta_w_b_h1
            w_bias_h1=w_bias_h1+delta_w_bias_h1

            delta_w_a_h2=learningRate*a*delta_h2
            delta_w_b_h2=learningRate*b*delta_h2
            delta_w_bias_h2=learningRate*1*delta_h2

            w_a_h2=w_a_h2+delta_w_a_h2
            w_b_h2=w_b_h2+delta_w_b_h2
            w_bias_h2=w_bias_h2+delta_w_bias_h2

            delta_w_a_h3=learningRate*a*delta_h3
            delta_w_b_h3=learningRate*b*delta_h3
            delta_bias_h3=learningRate*1*delta_h3

            w_a_h3=w_a_h3+delta_w_a_h3
            w_b_h3=w_b_h3+delta_w_b_h3
            w_bias_h3=w_bias_h3+delta_bias_h3

            new_list=[a,b,h1Output,h2Output,h3Output,finalOutput,int(y_train[j]),delta_h1,delta_h2,delta_h3,delta_o,w_bias_h1,
                      w_a_h1,w_b_h1,w_bias_h2,w_a_h2,w_b_h2,w_bias_h3,w_a_h3,w_b_h3,w_bias_o,w_h1_o,w_h2_o,w_h3_o]

            for j in range(0,len(new_list)):

                if(j==0 or j==1):
                    print(round(new_list[j],5),end=" ")

                elif(j==6):
                    print(new_list[j],end=" ")

                elif(j==len(new_list)-1):
                    print(round(new_list[j], 5))

                else:
                    print(round(new_list[j], 5), end=" ")


        i+=1

if __name__ == "__main__":
    expected_args = ["--data","--eta","--iterations"]
    arg_len = len(sys.argv)
    infomatik = []

    for i in range(len(expected_args)):
        for j in range(1, len(sys.argv)):
            if expected_args[i] == sys.argv[j] and sys.argv[j + 1]:
                infomatik.append(sys.argv[j + 1])

    data = pd.read_csv(infomatik[0], header=None)

    learningRate=infomatik[1]
    iters=infomatik[2]
    x_train = data.iloc[:,:-1].values
    y_train = data.iloc[:, -1].values
    # print(x_train, type(x_train))

    NN(x_train,y_train,iters,float(learningRate))